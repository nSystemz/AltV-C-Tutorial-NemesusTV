<template>
  <div id="app">
    <CharacterCreator/>
  </div>
</template>

<script>
import CharacterCreator from './components/CharacterCreator.vue'

export default {
  name: 'App',
  components: {
    CharacterCreator
  }
}
</script>

<style>
</style>
